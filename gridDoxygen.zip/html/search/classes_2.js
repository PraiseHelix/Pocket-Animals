var searchData=
[
  ['resourcemanager',['ResourceManager',['../class_resource_manager.html',1,'']]],
  ['resourcemanager_3c_20texturemanager_2c_20sf_3a_3atexture_20_3e',['ResourceManager&lt; TextureManager, sf::Texture &gt;',['../class_resource_manager.html',1,'']]]
];
